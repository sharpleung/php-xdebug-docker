<?php
/**
*	语言包
*/
class lang_zh_CNChajian extends Chajian{
	
	
	public function getLang()
	{
		$da = array(
			
		);
		return $da;
	}
}