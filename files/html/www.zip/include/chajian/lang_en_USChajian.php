<?php
/**
*	语言包(英文)，需要自行翻译
*/
class lang_en_USChajian extends Chajian{
	
	
	public function getLang()
	{
		$da = array(
			
		);
		return $da;
	}
}