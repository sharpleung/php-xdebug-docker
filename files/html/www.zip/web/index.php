<?php 
/**
*	跳转到手机移动端版本
*	主页：http://www.rockoa.com/
*	软件：信呼
*	作者：雨中磐石(rainrock)
*/
header('location:../?d=we');