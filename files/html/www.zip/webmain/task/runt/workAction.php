<?php
class workClassAction extends runtAction
{
	public function todoAction()
	{
		
		return 'success';
	}
}