<?php if(!defined('HOST'))die('not access');?>
<script >
$(document).ready(function(){
	
	
	
	var c = {
		
	};

	js.initbtn(c);
});
</script>


<div id="view_{rand}"><h1>文件上传到腾讯云的对象存储中</h1><br>查看这个<a target="_blank" href="<?=URLY?>view_txcos.html">帮助</a>去配置。</div>