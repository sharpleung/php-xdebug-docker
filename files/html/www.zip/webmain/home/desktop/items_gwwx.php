<?php 
/**
*	桌面首页项(通知公告)
*/
defined('HOST') or die ('not access');

?>

<div align="left"  class="list-group">
	<div class="list-group-item  list-group-item-default">
		<i class="icon-comments-alt"></i> <?=$itemnowname?>
	</div>
	<div  class="list-group-item">
		<table style="background:none">
		<tr valign="top">
		
		<td>
			<div style="line-height:26px;padding:5px;">结合了信呼OA系统，单据待办推送提醒到个人微信和企业微信上，也可快捷登录定位打卡，部门用户同步等，更多介绍<a href="<?=URLY?>view_weixinqy.html" target="_blank">[企业微信]</a>。<br>
			1、申请企业微信体验，去<a href="<?=URLY?>view_qywxty.html" target="_blank">[申请]</a>。<br>
			2、可到【系统→系统工具→升级系统】下安装，有问题？<a target="_blank" href="http://kefu.rockoa.com/?m=front&a=chat&key=6f46a242ffa9&cfrom=oanet">[<i class="icon-headphones"></i>信呼客服]</a>
			</div>
		</td>
		</tr></table>
	</div>
</div>

