<?php
class reimplat_userClassModel extends reimplatModel
{

}