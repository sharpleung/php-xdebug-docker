<?php
class flow_finfybxClassModel extends flowModel
{
	

}