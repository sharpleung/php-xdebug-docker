<?php
//文档模块word
class flow_wordClassModel extends flowModel
{


	
	
	
}